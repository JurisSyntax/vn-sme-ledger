"""Offline market reference data."""

import json
import os

CACHE_PATH = "data/market_cache.json"


def _load_cache():
    if os.path.exists(CACHE_PATH):
        try:
            with open(CACHE_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {}


def _save_cache(data):
    os.makedirs("data", exist_ok=True)
    with open(CACHE_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def get_exchange_rates(base="VND"):
    cache = _load_cache()
    if "exchange_rates" in cache:
        cache["exchange_rates"]["_source"] = "Local cache (offline)"
        return cache["exchange_rates"]
    return {
        "USD": 1.0,
        "VND": 25400,
        "EUR": 0.92,
        "JPY": 157,
        "CNY": 7.24,
        "_source": "Manual default (offline)",
        "_date": "N/A",
    }


def get_cpi_data():
    cache = _load_cache()
    if "cpi" in cache:
        return cache["cpi"]
    return {
        "data": [{"year": "2024", "cpi_pct": 3.6}, {"year": "2023", "cpi_pct": 3.25}, {"year": "2022", "cpi_pct": 3.15}],
        "_source": "Manual default (offline)",
        "_date": "N/A",
    }

