"""tabs_extra.py — Tax Calculator, Manual, MST Guide, VSIC, AI Assistant, HR tabs"""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json, os, datetime, subprocess, shutil, utils
from ai.llm_worker import OfflineAssistant
from ai.memory_profile import ProfileLimitError, ProfileStore
from core import legal_vault
from core.hr_compliance import payroll_snapshot

# ── Human-readable niche display names ─────────────────────
NICHE_NAMES = {
    "photocopy_print":       "In ấn / Photocopy",
    "retail_grocery":        "Bán lẻ / Tạp hóa",
    "services_consulting":   "Dịch vụ / Tư vấn",
    "clinic_pharmacy":       "Y tế / Nhà thuốc",
    "fnb_cafe":              "F&B / Nhà hàng / Café",
    "real_estate":           "Bất động sản",
    "construction":          "Xây dựng",
    "transport_logistics":   "Vận tải / Logistics",
    "education_training":    "Giáo dục / Đào tạo",
    "general_trade":         "Thương mại tổng hợp",
}

def load_vsic():
    p = "presets/vsic_industries.json"
    if os.path.exists(p):
        with open(p, "r", encoding="utf-8") as f: return json.load(f)
    return {}

def _add_copy_menu(w):
    m = tk.Menu(w, tearoff=0)
    def _copy():
        try:
            w.event_generate("<<Copy>>")
        except Exception:
            text = ""
            if hasattr(w, "cget"):
                try: text = w.cget("text")
                except Exception: text = ""
            if text:
                w.clipboard_clear()
                w.clipboard_append(text)
    def _paste():
        try:
            w.event_generate("<<Paste>>")
        except Exception:
            pass
    m.add_command(label="Sao chép (Copy)", command=_copy)
    if isinstance(w, (tk.Entry, tk.Text)):
        m.add_command(label="Dán (Paste)", command=_paste)
    w.bind("<Button-3>", lambda e: m.post(e.x_root, e.y_root))

def _make_readonly(event):
    if event.state & 4 and event.keysym.lower() in ('c', 'a'): return None
    if event.keysym in ('Up', 'Down', 'Left', 'Right', 'Prior', 'Next', 'Home', 'End'): return None
    return "break"

# ── Tax Calculator tab ─────────────────────────────────────
def build_tax_calc_tab(app, nb, lbl):
    import tax_calculator
    tab = ttk.Frame(nb)
    nb.add(tab, text="🧮")
    mode = ttk.Notebook(tab)
    mode.pack(fill="both", expand=True, padx=8, pady=4)
    
    # Household (TT40)
    h = ttk.Frame(mode); mode.add(h, text="🏠")
    f = ttk.LabelFrame(h, text="🏠 Tính thuế Hộ kinh doanh (TT40)"); f.pack(fill="x", padx=10, pady=8)
    tk.Label(f, text="Doanh thu / năm (VND):").grid(row=0, column=0, padx=6, pady=4, sticky="w")
    e_rev = tk.Entry(f, width=22); e_rev.grid(row=0, column=1, padx=6)
    cats = list(tax_calculator.TT40_RATES.keys())
    cat_labels = [f"{tax_calculator.TT40_RATES[k]['name_vi']}" for k in cats]
    v_cat = tk.StringVar(value=cat_labels[0])
    ttk.Combobox(f, textvariable=v_cat, values=cat_labels, state="readonly", width=50).grid(row=1, column=1, padx=6)
    
    res = tk.Text(h, height=12, wrap="word", font=("Consolas", 10))
    res.pack(fill="both", expand=True, padx=10, pady=4)
    _add_copy_menu(res); res.bind("<Key>", _make_readonly)

    def calc():
        try:
            r = tax_calculator.calc_household_tax(float(e_rev.get().replace(",","")), cats[cat_labels.index(v_cat.get())])
            res.delete("1.0", "end")
            if r["exempt"]: res.insert("end", f"⚡ {r['exempt_note']}\n\n")
            res.insert("end", f"Doanh thu: {r['revenue']:>20,.0f} VND\nNgành: {r['category']}\nVAT: {r['vat_amount']:>20,.0f} VND\nTNCN: {r['pit_amount']:>20,.0f} VND\n{'─'*50}\nTổng thuế: {r['total_tax']:>20,.0f} VND\n")
        except Exception as ex: messagebox.showerror("Lỗi", str(ex))
    tk.Button(f, text="Tính", command=calc, bg="#1565C0", fg="white", width=10).grid(row=0, column=2, rowspan=2, padx=12)

    # SME
    s = ttk.Frame(mode); mode.add(s, text="🏢")
    f2 = ttk.LabelFrame(s, text="🏢 Tính thuế Doanh nghiệp (Khấu trừ)"); f2.pack(fill="x", padx=10, pady=8)
    tk.Label(f2, text="Doanh thu (VND):").grid(row=0, column=0, padx=6, pady=4, sticky="w"); e_rev2 = tk.Entry(f2, width=22); e_rev2.grid(row=0, column=1, padx=6)
    tk.Label(f2, text="Chi phí (VND):").grid(row=1, column=0, padx=6, pady=4, sticky="w"); e_exp2 = tk.Entry(f2, width=22); e_exp2.grid(row=1, column=1, padx=6)
    tk.Label(f2, text="Thuế suất VAT:").grid(row=2, column=0, padx=6, pady=4, sticky="w")
    vat_keys = list(tax_calculator.SME_VAT_RATES.keys())
    vat_labels = [f"{tax_calculator.SME_VAT_RATES[k]['label']}" for k in vat_keys]
    v_vat = tk.StringVar(value=vat_labels[1])
    ttk.Combobox(f2, textvariable=v_vat, values=vat_labels, state="readonly", width=60).grid(row=2, column=1, padx=6)
    
    res2 = tk.Text(s, height=12, wrap="word", font=("Consolas", 10))
    res2.pack(fill="both", expand=True, padx=10, pady=4)
    _add_copy_menu(res2); res2.bind("<Key>", _make_readonly)

    def calc2():
        try:
            r = tax_calculator.calc_sme_tax(float(e_rev2.get().replace(",","")), float(e_exp2.get().replace(",","")), vat_keys[vat_labels.index(v_vat.get())])
            res2.delete("1.0", "end")
            res2.insert("end", f"Doanh thu: {r['revenue']:>20,.0f} VND\nChi phí: {r['expenses']:>20,.0f} VND\nVAT đầu ra ({r['vat_rate']*100:.0f}%): {r['vat_output']:>20,.0f} VND\nVAT đầu vào (ước tính): {r['vat_input_est']:>20,.0f} VND\nVAT phải nộp: {r['vat_payable']:>20,.0f} VND\n{'─'*55}\nLợi nhuận trước thuế: {r['profit_before_tax']:>20,.0f} VND\nThuế TNDN (20%): {r['cit_amount']:>20,.0f} VND\nLợi nhuận sau thuế: {r['net_profit']:>20,.0f} VND\n\n⚡ {r['vat_label']}")
        except Exception as ex: messagebox.showerror("Lỗi", str(ex))
    tk.Button(f2, text="Tính thuế", command=calc2, bg="#1565C0", fg="white", width=10).grid(row=0, column=2, rowspan=3, padx=12)

# ── Manual / Help tab ──────────────────────────────────────
def build_manual_tab(app, nb, lbl):
    import manual as manual_mod
    tab = ttk.Frame(nb)
    nb.add(tab, text="📘")
    txt = tk.Text(tab, wrap="word", font=("Arial", 10), padx=12, pady=8)
    sb = ttk.Scrollbar(tab, command=txt.yview)
    txt.config(yscrollcommand=sb.set)
    txt.pack(fill="both", expand=True, side="left")
    sb.pack(fill="y", side="right")
    txt.insert("end", manual_mod.get_manual_text())
    _add_copy_menu(txt)
    txt.bind("<Key>", _make_readonly)

# ── MST Lookup Guide tab ──────────────────────────────────
# ── Legal Templates 2026 tab ──────────────────────────────
def build_legal_docs_tab(app, nb, lbl):
    """Offline Legal Templates 2026."""
    tab = ttk.Frame(nb)
    nb.add(tab, text="📜")
    main_f = tk.Frame(tab, bg="#FFFFFF"); main_f.pack(fill="both", expand=True, padx=15, pady=15)
    
    h_f = tk.Frame(main_f, bg="#FFFFFF"); h_f.pack(fill="x")
    title_lbl = tk.Label(h_f, text="📁 KHO VĂN BẢN MẪU & QUY ĐỊNH PHÁP LUẬT 2026", font=("Segoe UI", 12, "bold"), bg="#FFFFFF", fg="#1565C0")
    title_lbl.pack(side="left", pady=10)
    _add_copy_menu(title_lbl)
    tk.Button(h_f, text="❓", command=lambda: messagebox.showinfo("Hướng dẫn", "Kho chỉ mở file đã lưu trong máy. Nếu chưa có bản lưu, phần mềm sẽ báo thiếu file để người dùng upload."), relief="flat").pack(side="right")

    manifest_path = os.path.join("db", "legal_manifest.json")
    storage_dir = os.path.join("docs", "templates_2026")
    docs = legal_vault.ensure_manifest(manifest_path, storage_dir)

    cols = ("title", "tag", "status", "basis")
    tree = ttk.Treeview(main_f, columns=cols, show="headings", height=15)
    heads = ["Tên Văn bản / Biểu mẫu", "Tag", "Trạng thái / Lưu trữ", "Cơ sở pháp lý"]
    for c, h in zip(cols, heads):
        tree.heading(c, text=h); tree.column(c, width=300 if c=="title" else 170)
    tree.pack(fill="both", expand=True)

    doc_by_item = {}
    def _refresh_docs():
        nonlocal docs
        docs = legal_vault.ensure_manifest(manifest_path, storage_dir)
        doc_by_item.clear()
        for item in tree.get_children(): tree.delete(item)
        for doc in docs:
            status = legal_vault.get_validity_status(doc)
            iid = tree.insert("", "end", values=(doc["title"], doc.get("tag",""), status, doc["legal_basis"]))
            doc_by_item[iid] = doc
    _refresh_docs()

    def _selected_doc():
        sel = tree.selection()
        if not sel:
            messagebox.showwarning("Thông báo", "Vui lòng chọn văn bản.")
            return None
        return doc_by_item.get(sel[0])

    def _copy_document():
        doc = _selected_doc()
        if not doc: return
        try:
            dest = legal_vault.make_document_copy(doc, os.path.join("docs", "copies"))
            messagebox.showinfo("Thành công", f"Đã tạo bản sao văn bản:\n{dest}")
            legal_vault.open_local_path(dest)
        except FileNotFoundError:
            messagebox.showwarning("Thiếu file", "⚠️ Không tìm thấy bản sao lưu. Hãy dùng nút Upload để lưu file Word/Excel/PDF vào kho.")
        except Exception as e:
            messagebox.showerror("Lỗi", str(e))

    def _open_selected_file():
        doc = _selected_doc()
        if not doc: return
        path = legal_vault.resolve_storage_path(doc)
        if not path.exists():
            messagebox.showwarning("Thiếu file", "⚠️ Không lưu trữ trên kho dữ liệu phần mềm")
            return
        try:
            legal_vault.open_local_path(path)
        except Exception as e:
            messagebox.showerror("Lỗi mở file", str(e))

    def _upload():
        sel = tree.selection()
        if not sel: return messagebox.showwarning("Thông báo", "Vui lòng chọn mục văn bản cần tải lên!")
        item_name = tree.item(sel[0])['values'][0]
        fpath = filedialog.askopenfilename(title=f"Chọn file cho: {item_name}", 
                                           filetypes=[("Excel/Word/PDF", "*.xlsx *.xls *.docx *.doc *.pdf"), ("All Files", "*.*")])
        if fpath:
            folder = os.path.join(os.getcwd(), "docs", "templates_2026")
            if not os.path.exists(folder): os.makedirs(folder)
            try:
                doc = doc_by_item[sel[0]]
                updated = legal_vault.register_upload(manifest_path, storage_dir, doc["id"], fpath)
                messagebox.showinfo("Thành công", f"Đã tải lên văn bản: {updated['storage_filename']}\nLưu tại: docs/templates_2026/")
                _refresh_docs()
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể tải lên: {e}")
        
    def _open_folder():
        folder = os.path.join(os.getcwd(), "docs", "templates_2026")
        if not os.path.exists(folder): os.makedirs(folder)
        os.startfile(folder)

    def _check():
        sel = tree.selection()
        if not sel: return messagebox.showwarning("Thông báo", "Vui lòng chọn văn bản cần kiểm tra!")
        doc = doc_by_item[sel[0]]
        status = legal_vault.get_validity_status(doc)
        msg = f"{status}\nCơ sở đối chiếu: {doc['legal_basis']}\nPattern: {doc.get('effective_pattern','')}"
        messagebox.showinfo("Kiểm tra tính pháp lý", msg)

    def _add_custom():
        def _save():
            name = e_name.get().strip()
            if not name: return
            rows = legal_vault.ensure_manifest(manifest_path, storage_dir)
            rows.append({
                "id": legal_vault.safe_filename(name).lower(),
                "title": name,
                "legal_basis": e_basis.get().strip() or name,
                "effective_pattern": e_basis.get().strip() or name,
                "tag": e_tag.get().strip() or "manual",
                "storage_filename": legal_vault.safe_filename(name) + ".docx",
                "storage_path": os.path.join(storage_dir, legal_vault.safe_filename(name) + ".docx"),
                "updated_at": datetime.date.today().isoformat(),
            })
            with open(manifest_path, "w", encoding="utf-8") as f:
                json.dump(rows, f, ensure_ascii=False, indent=2)
            _refresh_docs()
            utils.log_activity(f"Thêm mẫu văn bản thủ công: {name}")
            win.destroy()
            
        win = tk.Toplevel(app)
        win.title("Thêm văn bản mới")
        win.geometry("400x250")
        f = ttk.Frame(win, padding=20)
        f.pack(fill="both", expand=True)
        tk.Label(f, text="Tên văn bản:").pack(anchor="w")
        e_name = tk.Entry(f, width=40); e_name.pack(pady=5)
        tk.Label(f, text="Cơ sở pháp lý / mã văn bản:").pack(anchor="w")
        e_basis = tk.Entry(f, width=40); e_basis.pack(pady=5)
        tk.Label(f, text="Tag:").pack(anchor="w")
        e_tag = tk.Entry(f, width=20); e_tag.insert(0, "manual"); e_tag.pack(pady=5)
        tk.Button(f, text="Lưu", command=_save, bg="#388E3C", fg="white", width=15).pack(pady=15)

    btn_f = tk.Frame(main_f, bg="#FFFFFF"); btn_f.pack(fill="x", pady=10)
    tk.Button(btn_f, text="➕ Thêm văn bản mới", bg="#0288D1", fg="white", padx=10, command=_add_custom, font=("Segoe UI", 9, "bold")).pack(side="left", padx=5)
    tk.Button(btn_f, text="📄 Tạo bản sao", bg="#1565C0", fg="white", padx=10, command=_copy_document, font=("Segoe UI", 9, "bold")).pack(side="left", padx=5)
    tk.Button(btn_f, text="📂 Mở file đã lưu", bg="#546E7A", fg="white", padx=10, command=_open_selected_file, font=("Segoe UI", 9, "bold")).pack(side="left", padx=5)
    tk.Button(btn_f, text="📤 Tải lên mẫu (Upload)", bg="#2E7D32", fg="white", padx=10, command=_upload, font=("Segoe UI", 9, "bold")).pack(side="left", padx=5)
    tk.Button(btn_f, text="🔍 Kiểm tra hiệu lực", bg="#FF9800", fg="white", padx=10, command=_check, font=("Segoe UI", 9, "bold")).pack(side="left", padx=5)
    tk.Button(btn_f, text="📂 Mở thư mục", bg="#455A64", fg="white", padx=10, command=_open_folder, font=("Segoe UI", 9, "bold")).pack(side="right", padx=5)

# ── VSIC Industry Codes sub-tab ───────────────────────────
def build_vsic_subtab(app, sub_nb):
    tab = ttk.Frame(sub_nb)
    sub_nb.add(tab, text="🏢")
    vsic = load_vsic()
    def _on_search(event=None):
        query = e_search.get().lower().strip()
        for i in tree.get_children(): tree.delete(i)
        for g_name in vsic:
            for it in vsic[g_name]:
                if query in it.get("vsic","").lower() or query in it.get("name","").lower():
                    tree.insert("","end", values=(it.get("vsic",""), it.get("name",""), it.get("tax_cat","")))
    
    sf = ttk.Frame(tab); sf.pack(fill="x", padx=10, pady=5)
    tk.Label(sf, text="🔍 Tìm kiếm Ngành nghề (Mã hoặc Tên):", font=("Segoe UI", 9, "bold")).pack(side="left", padx=5)
    e_search = tk.Entry(sf, width=40); e_search.pack(side="left", padx=5)
    e_search.bind("<KeyRelease>", _on_search)
    
    tree = ttk.Treeview(tab, columns=("v", "n", "t"), show="headings", height=12)
    for c,h,w in [("v","Mã Ngành",80),("n","Tên Ngành Nghề Kinh Doanh",400),("t","Thuế suất Thông tư 40",150)]:
        tree.heading(c, text=h); tree.column(c, width=w)
    tree.pack(fill="both", expand=True)
    _on_search()

# ── ADVANCED AI AGENT TAB (v6.1 - Complete) ───────────────
def build_ai_tab(app, nb, lbl):
    """Offline AI assistant with profile memory and no HTTP/cloud calls."""
    tab = ttk.Frame(nb)
    nb.add(tab, text="🧠")
    
    main_f = tk.Frame(tab, bg="#FFFFFF"); main_f.pack(fill="both", expand=True)
    HISTORY_FILE = "data/ai_history.json"
    store = ProfileStore("data/ai_profiles.json")

    hdr = tk.Frame(main_f, bg="#FFFFFF"); hdr.pack(fill="x", padx=10, pady=8)
    tk.Label(hdr, text="Trợ lý AI offline - tối đa 03 profile", font=("Segoe UI", 12, "bold"), bg="#FFFFFF", fg="#1565C0").pack(side="left")
    profile_var = tk.StringVar()
    cmb_profile = ttk.Combobox(hdr, textvariable=profile_var, width=45, state="readonly")
    cmb_profile.pack(side="left", padx=12)

    def _refresh_profiles():
        values = [p["name"] for p in store.list_profiles()]
        cmb_profile["values"] = values
        if values and not profile_var.get():
            profile_var.set(values[0])
    _refresh_profiles()

    def _active_profile_notes():
        for profile in store.list_profiles():
            if profile["name"] == profile_var.get():
                return profile.get("notes", "")
        return ""

    def _add_profile():
        win = tk.Toplevel(app)
        win.title("Tạo profile AI")
        win.geometry("460x260")
        f = ttk.Frame(win, padding=14); f.pack(fill="both", expand=True)
        tk.Label(f, text="Tên profile:").pack(anchor="w")
        e_name = tk.Entry(f, width=52); e_name.pack(fill="x", pady=4)
        tk.Label(f, text="Ghi nhớ / phạm vi công việc:").pack(anchor="w")
        e_notes = tk.Text(f, height=6, wrap="word"); e_notes.pack(fill="both", expand=True, pady=4)
        _add_copy_menu(e_name); _add_copy_menu(e_notes)
        def _save():
            try:
                store.add_profile(e_name.get(), e_notes.get("1.0", "end"))
                _refresh_profiles()
                win.destroy()
            except ProfileLimitError as ex:
                messagebox.showwarning("Giới hạn profile", str(ex))
            except Exception as ex:
                messagebox.showerror("Lỗi", str(ex))
        tk.Button(f, text="Lưu profile", command=_save, bg="#388E3C", fg="white").pack(pady=6)
    tk.Button(hdr, text="➕ Profile", command=_add_profile, bg="#2E7D32", fg="white").pack(side="left")

    guide = tk.Label(
        main_f,
        text="Workflow: nhập yêu cầu → AI offline ghi nhận current_task → trả lời bằng dữ liệu/profile nội bộ. Không gọi cloud/API; phù hợp PC văn phòng 2 nhân CPU, RAM 4GB.",
        bg="#F8F9FA", fg="#333", justify="left", wraplength=900, padx=10, pady=8
    )
    guide.pack(fill="x", padx=10)
    _add_copy_menu(guide)

    txt_chat = tk.Text(main_f, wrap="word", font=("Segoe UI", 9), bg="#F8F9FA", relief="flat", height=15)
    txt_chat.tag_config("user_box", background="#E3F2FD", spacing1=5, spacing3=5, lmargin1=15)
    txt_chat.tag_config("ai_box", background="#FFFFFF", spacing1=5, spacing3=5, lmargin1=10)
    txt_chat.pack(fill="both", expand=True, padx=10, pady=6)
    _add_copy_menu(txt_chat)

    inp_f = tk.Frame(main_f, bg="#FFFFFF", bd=1, relief="solid"); inp_f.pack(fill="x", padx=10, pady=6)
    ent_msg = tk.Entry(inp_f, font=("Segoe UI", 10), relief="flat")
    ent_msg.pack(side="left", fill="x", expand=True, padx=5, pady=5)
    _add_copy_menu(ent_msg)

    def log_msg(sender, msg, style="ai"):
        txt_chat.config(state="normal")
        txt_chat.insert("end", f"{sender}\n", f"{style}_box")
        txt_chat.insert("end", f"{msg}\n\n", f"{style}_box")
        txt_chat.see("end")
        try:
            os.makedirs("data", exist_ok=True)
            with open(HISTORY_FILE, "w", encoding="utf-8") as f:
                json.dump({"chat": txt_chat.get("1.0", "end")}, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def send_msg(e=None):
        txt = ent_msg.get().strip()
        if not txt: return
        ent_msg.delete(0, "end")
        log_msg("Bạn", txt, "user")
        assistant = OfflineAssistant(_active_profile_notes())
        log_msg("AI", assistant.answer(txt), "ai")

    tk.Button(inp_f, text="Gửi", command=send_msg, bg="#1565C0", fg="white", font=("Segoe UI", 9, "bold")).pack(side="right", padx=5)
    ent_msg.bind("<Return>", send_msg)

    if os.path.exists(HISTORY_FILE):
        try:
            with open(HISTORY_FILE, "r", encoding="utf-8") as f:
                txt_chat.insert("end", json.load(f).get("chat", ""))
                txt_chat.see("end")
        except Exception:
            pass

# ── Payroll & HR Tab (ENHANCED 2026) ──────────────────────
def build_payroll_tab(app, nb, lbl):
    tab = ttk.Frame(nb)
    nb.add(tab, text="👥")
    EMP_FILE = "data/employees.json"
    
    def calc_pit(taxable_income):
        # Biểu thuế lũy tiến từng phần 2026 (Giả định quy định chuẩn)
        if taxable_income <= 0: return 0
        brackets = [
            (5000000, 0.05, 0),
            (10000000, 0.1, 250000),
            (18000000, 0.15, 750000),
            (32000000, 0.2, 1650000),
            (52000000, 0.25, 3250000),
            (80000000, 0.3, 5850000),
            (float('inf'), 0.35, 9850000)
        ]
        prev_limit = 0
        for limit, rate, deduct in brackets:
            if taxable_income <= limit:
                return taxable_income * rate - deduct
        return 0

    def load_emp():
        if os.path.exists(EMP_FILE):
            try:
                with open(EMP_FILE, "r", encoding="utf-8") as f: return json.load(f)
            except: pass
        return []

    def save_emp(data):
        os.makedirs("data", exist_ok=True)
        with open(EMP_FILE, "w", encoding="utf-8") as f: json.dump(data, f, ensure_ascii=False, indent=2)

    h_f = ttk.Frame(tab); h_f.pack(fill="x")
    tk.Label(h_f, text="👥 QUẢN LÝ NHÂN SỰ & BẢNG LƯƠNG 2026", font=("Segoe UI", 11, "bold")).pack(side="left", padx=15, pady=5)
    tk.Button(h_f, text="❓", command=lambda: messagebox.showinfo("Hướng dẫn", "Quản lý nhân viên, tính lương theo quy định 2026. Bao gồm Bảo hiểm (10.5%) và Thuế TNCN lũy tiến."), relief="flat").pack(side="right", padx=15)
    
    main_f = ttk.Frame(tab); main_f.pack(fill="both", expand=True, padx=15, pady=15)
    
    # Left: List
    left = ttk.LabelFrame(main_f, text="📋 Bảng lương & Nhân sự")
    left.pack(side="left", fill="both", expand=True, padx=5)
    
    cols = ("id", "name", "year", "role", "sal", "allow", "ins", "union", "pit", "net", "status")
    tree = ttk.Treeview(left, columns=cols, show="headings", height=15)
    heads = ["Mã NV", "Họ và Tên", "Năm", "Chức danh", "Lương Cơ bản", "Phụ cấp", "BHXH/BHYT/BHTN", "Công đoàn 2%", "Thuế TNCN", "Thực lĩnh", "Cảnh báo"]
    for c, h in zip(cols, heads):
        tree.heading(c, text=h); tree.column(c, width=110 if len(c)>2 else 60)
    tree.pack(fill="both", expand=True, padx=10, pady=10)
    
    # Right: Form
    right = tk.Frame(main_f); right.pack(side="right", fill="y", padx=5)
    f_form = ttk.LabelFrame(right, text="👤 Thông tin & Cấu hình"); f_form.pack(fill="x")
    
    fields_cfg = [
        ("Mã Nhân viên:", "code", "entry"), ("Họ và Tên:", "name", "entry"), 
        ("Chức danh:", "role", "combo"), ("Lương Cơ bản:", "salary", "entry"), 
        ("Phụ cấp:", "allowance", "entry"), ("Người phụ thuộc:", "dependents", "entry"),
        ("Năm lương:", "salary_year", "entry"), ("Giờ OT/tháng:", "overtime_hours", "entry")
    ]
    entries = {}
    roles = ["Giám đốc", "Phó Giám đốc", "Kế toán trưởng", "Kế toán viên", "Trưởng phòng", "Nhân viên kinh doanh", "Kỹ thuật viên", "Cộng tác viên"]
    
    for i, (label, key, tip) in enumerate(fields_cfg):
        tk.Label(f_form, text=label).grid(row=i, column=0, padx=5, pady=3, sticky="w")
        if tip == "combo":
            e = ttk.Combobox(f_form, values=roles, width=18)
        else:
            e = tk.Entry(f_form, width=20)
            if key in ["salary", "allowance", "dependents", "overtime_hours"]: e.insert(0, "0")
            if key == "salary_year": e.insert(0, "2026")
        e.grid(row=i, column=1, padx=5, pady=3)
        entries[key] = e

    def refresh():
        for i in tree.get_children(): tree.delete(i)
        for e in load_emp():
            sal = float(e.get('salary', 0))
            allow = float(e.get('allowance', 0))
            deps = int(e.get('dependents', 0))
            year = int(e.get('salary_year', 2026) or 2026)
            ot = float(e.get('overtime_hours', 0) or 0)
            
            snap = payroll_snapshot(sal, allow, deps, ot)
            ins = float(snap["insurance"])
            taxable = (sal + allow) - ins - 11000000 - (deps * 4400000)
            pit = calc_pit(taxable)
            union_due = float(snap["union_due"])
            net = (sal + allow) - ins - pit
            status = "; ".join(snap["warnings"]) or "OK"
            
            tree.insert("", "end", values=(
                e.get("code",""), e.get("name",""), year, e.get("role",""),
                f"{sal:,.0f}", f"{allow:,.0f}", f"{ins:,.0f}", f"{union_due:,.0f}", f"{pit:,.0f}", f"{net:,.0f}", status
            ))
    
    def add_emp():
        data = load_emp()
        new_e = {k: e.get() for k, e in entries.items()}
        if not new_e['code']: return messagebox.showwarning("Lỗi", "Nhập Mã NV")
        # Update if exists
        data = [x for x in data if x['code'] != new_e['code']]
        data.append(new_e); save_emp(data)
        try:
            snap = payroll_snapshot(float(new_e.get("salary", 0)), float(new_e.get("allowance", 0)), int(new_e.get("dependents", 0)), float(new_e.get("overtime_hours", 0)))
            app.db.execute(
                """INSERT INTO employee_ledger
                   (employee_code,employee_name,salary_year,base_salary,allowance,union_due,compliance_status)
                   VALUES (?,?,?,?,?,?,?)""",
                (
                    new_e.get("code", ""),
                    new_e.get("name", ""),
                    int(new_e.get("salary_year", 2026) or 2026),
                    float(new_e.get("salary", 0) or 0),
                    float(new_e.get("allowance", 0) or 0),
                    float(snap["union_due"]),
                    "; ".join(snap["warnings"]) or "OK",
                ),
            )
            app.db.commit()
        except Exception:
            pass
        refresh()

    def del_emp():
        sel = tree.selection()
        if not sel: return
        code = tree.item(sel[0])['values'][0]
        data = [e for e in load_emp() if e.get('code') != str(code)]
        save_emp(data); refresh()

    def export_payroll_excel():
        data = load_emp()
        if not data: return messagebox.showwarning("Thông báo", "Không có dữ liệu để xuất!")
        fpath = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV (Excel)", "*.csv"), ("All Files", "*.*")])
        if fpath:
            import csv
            try:
                with open(fpath, "w", encoding="utf-8-sig", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=["code", "name", "role", "salary", "allowance", "dependents", "salary_year", "overtime_hours"])
                    w.writeheader()
                    w.writerows(data)
                messagebox.showinfo("Thành công", f"Đã xuất dữ liệu ra: {fpath}")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể xuất file: {e}")

    def export_payroll_word():
        data = load_emp()
        if not data: return messagebox.showwarning("Thông báo", "Không có dữ liệu!")
        fpath = filedialog.asksaveasfilename(defaultextension=".doc", filetypes=[("Word Document", "*.doc")])
        if fpath:
            try:
                html = "<html><meta charset='utf-8'><body>"
                html += "<h2 style='text-align:center;'>DANH SÁCH NHÂN VIÊN</h2>"
                html += "<table border='1' style='border-collapse:collapse;width:100%;'>"
                html += "<tr style='background:#EEE;'><th>Mã NV</th><th>Họ và Tên</th><th>Chức danh</th><th>Lương CB</th><th>Phụ cấp</th></tr>"
                for e in data:
                    html += f"<tr><td>{e.get('code','')}</td><td>{e.get('name','')}</td><td>{e.get('role','')}</td>"
                    html += f"<td>{float(e.get('salary',0)):,.0f}</td><td>{float(e.get('allowance',0)):,.0f}</td></tr>"
                html += "</table></body></html>"
                with open(fpath, "w", encoding="utf-8") as f: f.write(html)
                messagebox.showinfo("Thành công", f"Đã xuất danh sách nhân sự ra Word:\n{fpath}")
                os.startfile(fpath)
            except Exception as e:
                messagebox.showerror("Lỗi", str(e))

    def import_payroll():
        fpath = filedialog.askopenfilename(filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")])
        if fpath:
            import csv
            try:
                new_data = []
                with open(fpath, "r", encoding="utf-8-sig") as f:
                    r = csv.DictReader(f)
                    for row in r: new_data.append(dict(row))
                save_emp(new_data); refresh()
                messagebox.showinfo("Thành công", "Đã nhập dữ liệu nhân sự mới!")
            except Exception as e:
                messagebox.showerror("Lỗi", f"Không thể nhập file: {e}")

    btn_f = ttk.Frame(right); btn_f.pack(pady=10)
    tk.Button(btn_f, text="💾 Lưu/Cập nhật", command=add_emp, bg="#388E3C", fg="white", width=18).pack(side="top", pady=3)
    tk.Button(btn_f, text="❌ Xóa nhân viên", command=del_emp, bg="#D32F2F", fg="white", width=18).pack(side="top", pady=3)
    
    # Export/Import buttons
    tk.Label(right, text="📂 QUẢN LÝ DỮ LIỆU", font=("Segoe UI", 9, "bold"), fg="#555").pack(pady=(15, 5))
    tk.Button(right, text="📊 Xuất Excel (CSV)", command=export_payroll_excel, bg="#455A64", fg="white", width=18).pack(pady=3)
    tk.Button(right, text="📄 Xuất Word (Doc)", command=export_payroll_word, bg="#455A64", fg="white", width=18).pack(pady=3)
    tk.Button(right, text="📥 Nhập dữ liệu", command=import_payroll, bg="#455A64", fg="white", width=18).pack(pady=3)
    
    refresh()
