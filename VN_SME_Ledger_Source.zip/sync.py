"""Local-only backup/sync helpers.

The app is intentionally offline-first. Network sync, webhook upload, SFTP,
and online tax refresh are disabled to prevent accidental data disclosure.
"""

from __future__ import annotations

import os
import shutil
from datetime import datetime


def is_online() -> bool:
    return False


def run_sync(conn=None) -> str:
    os.makedirs("data/backups", exist_ok=True)
    source = "data/ledger.db"
    if not os.path.exists(source):
        return "Offline-only: chưa có data/ledger.db để sao lưu"
    dest = f"data/backups/ledger_{datetime.now():%Y%m%d_%H%M%S}.db"
    shutil.copy2(source, dest)
    return f"Offline-only: đã tạo bản sao lưu cục bộ {dest}"


def upload_to_cloud(file_path: str, settings: dict | None = None) -> str:
    if not os.path.exists(file_path):
        return "Offline-only: file sao lưu không tồn tại"
    backup_dir = "backups"
    os.makedirs(backup_dir, exist_ok=True)
    dest = os.path.join(backup_dir, os.path.basename(file_path))
    if os.path.abspath(file_path) != os.path.abspath(dest):
        shutil.copy2(file_path, dest)
    return "Offline-only: cloud/webhook/SFTP đã tắt; chỉ lưu bản sao cục bộ"

